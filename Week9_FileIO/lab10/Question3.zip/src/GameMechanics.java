import java.util.ArrayList;

public class GameMechanics {

    public static boolean BattleTester(ArrayList parameters)
    {
        for(int i = 0; i < parameters.size()-1; i++)
        {
                if(parameters.get(i) instanceof Villain)
                {
                    return false;
                }        
        }
        return true;
    }

    public static void basicWinChances(Character o1, Character o2)
    {
        System.out.println("Printed Ratio: ");
        System.out.println(o1.getHearts() + " to " + o2.getHearts());
        System.out.println("Winner: ");
        if(o1.getHearts() > o2.getHearts())
        {
            System.out.println(o1.getName());
        }
        else
        {
            System.out.println(o2.getName());
        }
    }
}