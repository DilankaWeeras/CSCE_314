import java.util.ArrayList;

public class GameMechanics {

    public static boolean BattleTester(ArrayList parameters)
    {
        for(int i = 0; i < parameters.size()-1; i++)
        {
                if(parameters.get(i) instanceof Villain)
                {
                    return false;
                }        
        }
        return true;
    }
}